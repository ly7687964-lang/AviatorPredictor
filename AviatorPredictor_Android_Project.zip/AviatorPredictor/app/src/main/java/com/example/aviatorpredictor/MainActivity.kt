package com.example.aviatorpredictor

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var summary: TextView
    private val requestCapture = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(Color.rgb(16, 24, 39))
        }
        val title = TextView(this).apply {
            text = "✈️ Aviator Predictor"
            textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "قارئ نتائج تجريبي — يقرأ النص الظاهر على الشاشة بإذن تسجيل الشاشة."
            textSize = 15f; setTextColor(Color.LTGRAY); setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "بدء قراءة الشاشة"
            setOnClickListener {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
            }
        }
        val refresh = Button(this).apply {
            text = "تحديث الإحصائيات"
            setOnClickListener { refreshSummary() }
        }
        summary = TextView(this).apply {
            textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 24, 0, 0)
        }
        box.addView(title); box.addView(info); box.addView(start); box.addView(refresh); box.addView(summary)
        setContentView(box)
        refreshSummary()
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode); putExtra("data", data)
            }
            startForegroundService(service)
            summary.text = "بدأت القراءة. افتح لعبة Aviator وأظهر نافذة السجل حتى يلتقط التطبيق المضاعفات."
        }
    }

    private fun refreshSummary() {
        val prefs = getSharedPreferences("aviator_data", MODE_PRIVATE)
        val values = prefs.getStringSet("multipliers", emptySet())?.toList().orEmpty()
            .mapNotNull { it.toFloatOrNull() }.sorted()
        if (values.isEmpty()) {
            summary.text = "لا توجد نتائج مقروءة بعد. افتح سجل اللعبة أثناء تشغيل القراءة."
        } else {
            val avg = values.average()
            summary.text = "النتائج المحفوظة: ${values.size}\nالمتوسط: %.2fx\nأعلى نتيجة: %.2fx\nأقل نتيجة: %.2fx\n\nهذه إحصائيات للماضي فقط، وليست توقعًا للجولة القادمة."
                .format(avg, values.maxOrNull(), values.minOrNull())
        }
    }
}
