package com.example.aviatorpredictor

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.regex.Pattern

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private lateinit var worker: Handler
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val seen = mutableSetOf<String>()

    override fun onCreate() {
        super.onCreate()
        val thread = HandlerThread("AviatorOCR").apply { start() }
        worker = Handler(thread.looper)
        val channel = "aviator_capture"
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "قراءة الشاشة", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = Notification.Builder(this, channel)
            .setContentTitle("Aviator Predictor يعمل")
            .setContentText("افتح سجل اللعبة لقراءة النتائج الظاهرة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(11, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, worker)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "AviatorScreen", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, worker
        )
        reader?.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            processImage(image)
        }, worker)
        return START_STICKY
    }

    private fun processImage(image: Image) {
        val input = InputImage.fromMediaImage(image, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                // Reads visible multiplier strings (e.g. x1.18). It does not access account data.
                val pattern = Pattern.compile("(?i)x\\s*([0-9]{1,4}(?:[.,][0-9]{1,2})?)")
                val matcher = pattern.matcher(result.text)
                val prefs = getSharedPreferences("aviator_data", MODE_PRIVATE)
                val saved = prefs.getStringSet("multipliers", emptySet())?.toMutableSet() ?: mutableSetOf()
                while (matcher.find()) {
                    val value = matcher.group(1)?.replace(',', '.') ?: continue
                    val number = value.toFloatOrNull() ?: continue
                    if (number >= 1f && number <= 100000f) {
                        val key = "%.2f".format(java.util.Locale.US, number)
                        if (seen.add(key + "_" + System.currentTimeMillis()/3000)) saved.add(key)
                    }
                }
                prefs.edit().putStringSet("multipliers", saved).apply()
            }
            .addOnCompleteListener { image.close() }
    }

    override fun onDestroy() {
        reader?.close(); display?.release(); projection?.stop(); recognizer.close()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
